# Panel privado Chusmi

Panel: https://web.promatrix.es/admin

Autoriza usuarios IPTV exactos, sin guardar sus contraseñas en la lista. Los usuarios no incluidos o bloqueados no pueden iniciar sesión ni acceder a catálogos o vídeos por API. La aprobación no sustituye la autenticación IPTV: el proveedor sigue comprobando usuario y contraseña.

Funciones: añadir cliente y nombre, buscar, bloquear, volver a autorizar, eliminar, consultar última actividad, ver sesiones abiertas y cerrar una sesión. La actualización del panel es cada 15 segundos mientras esté visible. Actividad reciente significa una petición en los últimos 90 segundos, no que el cliente esté viendo un canal ni el estado del panel del proveedor.

## Instalar en el VPS

Descomprime este ZIP en una carpeta aparte y ejecuta `python3 install.py` como root. El instalador crea tu contraseña administrativa (mínimo 16 caracteres) y autoriza inicialmente tu propio usuario IPTV. Las contraseñas se introducen solo en el terminal del VPS y no se ven al escribir.

Envuelve el servidor actual sin sustituir server.py, app.js, CSS, reproductor ni ajustes existentes. Añade admin_gate.py, admin_assets, una configuración Compose y una carpeta persistente .access-data. Reinicia la web para activar el control; las sesiones IPTV anteriores se cierran. No cambia la APK, su panel de activación ni el VPS/VPN del proveedor. No sobrescribe una configuración Compose adicional ajena.

La lista y la huella de la contraseña administrativa se guardan en SQLite en .access-data, montada en /data dentro del contenedor. Solo se almacena una huella PBKDF2 de la contraseña de administración, nunca la contraseña en texto. Las credenciales IPTV de sesiones activas siguen en la memoria del servidor existente. Protege las copias de .access-data; no las subas a GitHub.

## Uso

Entra en /admin con tu contraseña administrativa. Añade el usuario IPTV exacto y opcionalmente un nombre. Bloquear o eliminar corta sus sesiones abiertas y evita el acceso futuro. «Cerrar sesión» expulsa esa sesión, pero permite volver a entrar si sigue autorizado. No se cambia nada en el panel IPTV del proveedor; su indicador puede tardar en reflejar una desconexión.

La sesión administrativa caduca tras 30 minutos sin peticiones. Mientras el panel esté abierto y visible se renueva al actualizarse. Usa «Salir del panel» al terminar. Reiniciar el contenedor cierra las sesiones, pero conserva los clientes.

Si necesitas desactivar el panel, restaura el Dockerfile de backup-panel-* y reconstruye con `docker compose up -d --build`. Conserva .access-data para poder recuperarlo. Desactivar el panel restaura el acceso solo con credenciales IPTV.
