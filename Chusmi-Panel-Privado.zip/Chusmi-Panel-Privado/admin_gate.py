"""Persistent client approvals; wraps the deployed server without replacing it."""
import hashlib
import hmac
import io
import json
import os
import secrets
import socket
import sqlite3
import threading
import time
from collections import deque
from contextlib import contextmanager
from http.cookies import SimpleCookie
from pathlib import Path
import server

DB = Path(os.environ.get('ACCESS_DB', '/data/access.sqlite3'))
ASSETS = Path(__file__).parent / 'admin_assets'
ADMIN_SESSIONS = {}
ATTEMPTS = {}
LOCK = threading.RLock()
COOKIE = 'chusmi_admin'

@contextmanager
def connection():
    db = sqlite3.connect(DB, timeout=10)
    db.row_factory = sqlite3.Row
    try:
        with db:
            yield db
    finally:
        db.close()

def approved(username):
    with connection() as db:
        row = db.execute('SELECT enabled FROM clients WHERE username=?', (username,)).fetchone()
    return bool(row and row['enabled'])

def touch(account):
    now = time.time()
    account['_access_seen'] = now
    if now - account.get('_access_saved', 0) >= 30:
        account['_access_saved'] = now
        with connection() as db:
            db.execute('UPDATE clients SET last_seen=? WHERE username=?', (now, account['username']))

def client_account(env):
    try:
        return server.account_for(env)
    except server.Failure:
        return None

def close_account(account):
    account['expires'] = 0
    with server.LOCK:
        responses = [r for group in account.get('_streams', {}).values() for r in group]
    for response in responses:
        try:
            response.fp.raw._sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            response.close()
        except Exception:
            pass

def revoke(username=None, session_ref=None):
    with server.LOCK:
        matches = [(sid, account) for sid, account in server.SESSIONS.items()
                   if (username is not None and account['username'] == username)
                   or (session_ref is not None and session_id(sid) == session_ref)]
        for sid, account in matches:
            server.SESSIONS.pop(sid, None)
    for sid, account in matches:
        close_account(account)

def session_id(sid):
    return hashlib.sha256(sid.encode()).hexdigest()[:24]

def admin_session(env):
    jar = SimpleCookie()
    try:
        jar.load(env.get('HTTP_COOKIE', ''))
    except Exception:
        return None
    token = jar.get(COOKIE)
    now = time.time()
    with LOCK:
        for key in list(ADMIN_SESSIONS):
            if ADMIN_SESSIONS[key]['expires'] < now:
                ADMIN_SESSIONS.pop(key, None)
        session = ADMIN_SESSIONS.get(token.value) if token else None
        if session:
            session['expires'] = now + 1800
    return session

def read_json(env):
    try:
        length = int(env.get('CONTENT_LENGTH') or 0)
        if not 0 < length <= 4096:
            raise ValueError()
        data = json.loads(env['wsgi.input'].read(length))
        if not isinstance(data, dict):
            raise ValueError()
        return data
    except (ValueError, UnicodeError):
        raise server.Failure(400, 'Solicitud no válida.')

def send(start_response, status, data, mime='application/json; charset=utf-8', extra=()):
    if mime.startswith('application/json'):
        data = json.dumps(data, ensure_ascii=False).encode()
    elif isinstance(data, str):
        data = data.encode()
    headers = [('Content-Type', mime), ('Content-Length', str(len(data))),
               ('Cache-Control', 'no-store'), ('X-Content-Type-Options', 'nosniff'),
               ('Referrer-Policy', 'no-referrer'), ('X-Frame-Options', 'DENY')]
    headers += list(extra)
    start_response(str(status) + ' ' + {200:'OK', 400:'Bad Request', 401:'Unauthorized',
                   403:'Forbidden', 404:'Not Found', 409:'Conflict', 429:'Too Many Requests',
                   503:'Service Unavailable'}.get(status, 'Error'), headers)
    return [data]

def same_origin(env):
    if env.get('HTTP_SEC_FETCH_SITE') == 'cross-site':
        return False
    supplied = env.get('HTTP_ORIGIN')
    expected = env.get('wsgi.url_scheme', 'http') + '://' + env.get('HTTP_HOST', '')
    return supplied == expected and env.get('CONTENT_TYPE', '').startswith('application/json')

def snapshot():
    now = time.time()
    with server.LOCK:
        sessions = [{'id': session_id(sid), 'username': a['username'],
                     'last_seen': a.get('_access_seen', 0),
                     'recent': now-a.get('_access_seen', 0) < 90}
                    for sid, a in list(server.SESSIONS.items()) if a['expires'] > now]
    with connection() as db:
        clients = [dict(r) for r in db.execute('SELECT * FROM clients ORDER BY created DESC')]
    return {'clients':clients, 'sessions':sessions, 'now':now}

def application(env, start_response):
    path, method = env.get('PATH_INFO', '/'), env.get('REQUEST_METHOD', 'GET')
    try:
        if path in ('/admin', '/admin/') and method == 'GET':
            return send(start_response, 200, (ASSETS/'index.html').read_bytes(), 'text/html; charset=utf-8',
                        [('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")])
        if path.startswith('/admin-assets/') and method == 'GET':
            name = path.split('/')[-1]
            if name not in ('admin.js', 'admin.css'):
                return send(start_response, 404, {'error':'No encontrado.'})
            mime = 'text/javascript; charset=utf-8' if name.endswith('.js') else 'text/css; charset=utf-8'
            return send(start_response, 200, (ASSETS/name).read_bytes(), mime)
        if path == '/admin-heartbeat.js' and method == 'GET':
            return send(start_response, 200, (ASSETS/'heartbeat.js').read_bytes(), 'text/javascript; charset=utf-8')
        if path.startswith('/admin/api/'):
            if method == 'POST' and not same_origin(env):
                raise server.Failure(403, 'Origen no permitido.')
            if path == '/admin/api/login' and method == 'POST':
                key = env.get('HTTP_X_REAL_IP', env.get('REMOTE_ADDR', 'unknown'))
                now = time.time()
                with LOCK:
                    for old in list(ATTEMPTS):
                        if not ATTEMPTS[old] or ATTEMPTS[old][-1] < now-600:
                            ATTEMPTS.pop(old, None)
                    if key not in ATTEMPTS and len(ATTEMPTS) >= 4096:
                        raise server.Failure(429, 'Demasiados intentos. Espera diez minutos.')
                    attempts = ATTEMPTS.setdefault(key, deque())
                    while attempts and attempts[0] < now-600:
                        attempts.popleft()
                    if len(attempts) >= 10:
                        raise server.Failure(429, 'Demasiados intentos. Espera diez minutos.')
                    attempts.append(now)
                data = read_json(env)
                with connection() as db:
                    settings = dict(db.execute('SELECT key,value FROM settings').fetchall())
                digest = hashlib.pbkdf2_hmac('sha256', str(data.get('password','')).encode(),
                                           bytes.fromhex(settings['salt']), 600000).hex()
                if not hmac.compare_digest(digest, settings['password_hash']):
                    raise server.Failure(401, 'Contraseña incorrecta.')
                token = secrets.token_urlsafe(32)
                csrf = secrets.token_urlsafe(32)
                with LOCK:
                    if len(ADMIN_SESSIONS) >= 50:
                        raise server.Failure(429, 'Demasiadas sesiones administrativas.')
                    ADMIN_SESSIONS[token] = {'csrf':csrf, 'expires':now+1800}
                return send(start_response, 200, {'csrf':csrf}, extra=[('Set-Cookie',
                            f'{COOKIE}={token}; Path=/admin; Secure; HttpOnly; SameSite=Strict')])
            session = admin_session(env)
            if not session:
                raise server.Failure(401, 'Entra en el panel privado.')
            if method == 'GET' and path == '/admin/api/state':
                return send(start_response, 200, {**snapshot(), 'csrf':session['csrf']})
            if method != 'POST' or not hmac.compare_digest(env.get('HTTP_X_ADMIN_CSRF',''),session['csrf']):
                raise server.Failure(403, 'Solicitud no autorizada.')
            data = read_json(env)
            if path == '/admin/api/logout':
                with LOCK:
                    for token, value in list(ADMIN_SESSIONS.items()):
                        if value is session:
                            ADMIN_SESSIONS.pop(token, None)
                return send(start_response, 200, {'ok':True}, extra=[('Set-Cookie',
                    f'{COOKIE}=; Path=/admin; Secure; HttpOnly; SameSite=Strict; Max-Age=0')])
            if path == '/admin/api/session/close':
                revoke(session_ref=str(data.get('id','')))
                return send(start_response, 200, {'ok':True})
            username = str(data.get('username','')).strip()
            name = str(data.get('name','')).strip()
            if not username or len(username)>200 or len(name)>120 or any(ord(x)<32 for x in username+name):
                raise server.Failure(400, 'Introduce un usuario válido y un nombre de hasta 120 caracteres.')
            with connection() as db:
                if path == '/admin/api/client/add':
                    try:
                        db.execute('INSERT INTO clients(username,name,enabled,created,last_seen) VALUES(?,?,1,?,0)',
                                   (username,name,time.time()))
                    except sqlite3.IntegrityError:
                        raise server.Failure(409, 'Ese usuario ya está en la lista.')
                elif path == '/admin/api/client/status':
                    enabled = data.get('enabled') is True
                    db.execute('UPDATE clients SET enabled=? WHERE username=?', (int(enabled),username))
                elif path == '/admin/api/client/remove':
                    db.execute('DELETE FROM clients WHERE username=?', (username,))
                else:
                    raise server.Failure(404, 'No encontrado.')
            if path == '/admin/api/client/remove' or (path == '/admin/api/client/status' and not enabled):
                revoke(username=username)
            return send(start_response, 200, {'ok':True})

        if path == '/api/login' and method == 'POST':
            if not same_origin(env):
                raise server.Failure(403, 'Origen no permitido.')
            data = read_json(env)
            if not approved(str(data.get('username','')).strip()):
                raise server.Failure(403, 'Tu usuario no tiene acceso autorizado a esta web. Contacta con Chusmi.')
            raw = json.dumps(data).encode()
            env['wsgi.input'] = io.BytesIO(raw)
            env['CONTENT_LENGTH'] = str(len(raw))
        account = client_account(env) if path.startswith(('/api/', '/media/')) and path != '/api/login' else None
        if account and path != '/api/logout':
            if not approved(account['username']):
                revoke(username=account['username'])
                raise server.Failure(403, 'Tu acceso a esta web está bloqueado. Contacta con Chusmi.')
            touch(account)
        if path == '/api/access-status' and method == 'GET':
            if not account:
                raise server.Failure(401, 'Inicia sesión para continuar.')
            return send(start_response, 200, {'ok':True})
        if path == '/' and method == 'GET':
            content = (server.ROOT/'templates/index.html').read_text()
            content = content.replace('</head>', '<script defer src="/admin-heartbeat.js"></script></head>')
            return send(start_response, 200, content, 'text/html; charset=utf-8', [('Content-Security-Policy',
                "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self'; img-src 'self' https: data:; media-src 'self' blob:; connect-src 'self'; worker-src blob:; frame-ancestors 'none'; base-uri 'self'")])
        iterable = server.application(env, start_response)
        if account and path.startswith('/media/'):
            def stream():
                checked = 0
                try:
                    for chunk in iterable:
                        now = time.time()
                        if account['expires'] <= now:
                            break
                        if now-checked >= 1:
                            checked = now
                            if not approved(account['username']):
                                break
                            touch(account)
                        yield chunk
                finally:
                    if hasattr(iterable, 'close'):
                        iterable.close()
            return stream()
        return iterable
    except server.Failure as e:
        return send(start_response, e.status, {'error':e.message})
    except (sqlite3.Error, KeyError, OSError):
        return send(start_response, 503, {'error':'El control de acceso no está disponible. Inténtalo más tarde.'})
