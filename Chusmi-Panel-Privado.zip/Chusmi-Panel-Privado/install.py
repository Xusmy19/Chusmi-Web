"""Run on the Contabo VPS as root; preserves the deployed player and settings."""
import getpass
import hashlib
import json
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

def main():
    if os.geteuid() != 0:
        raise SystemExit('Ejecuta este instalador como root en el VPS.')
    source = Path(__file__).resolve().parent
    target = Path('/opt/chusmi/Chusmi-Web')
    docker = target/'Dockerfile'
    override = target/'compose.override.yaml'
    if not docker.is_file() or not (target/'server.py').is_file():
        raise SystemExit('No se encontró la instalación de Chusmi Web.')
    text = docker.read_text()
    if 'server:application' not in text and 'admin_gate:application' not in text:
        raise SystemExit('El Dockerfile no coincide. No se ha cambiado nada.')
    expected = 'services:\n  chusmi-web:\n    volumes:\n      - ./.access-data:/data\n'
    if override.exists() and override.read_text() != expected:
        raise SystemExit('Ya existe otra configuración adicional. No se ha cambiado nada; envía ese aviso.')
    print('Instalación del panel privado. No modifica la APK ni el servidor IPTV.')
    print('La contraseña del administrador solo se introduce aquí, en tu VPS.')
    state = target/'.access-data'
    dbfile = state/'access.sqlite3'
    fresh = not dbfile.exists()
    if fresh:
        password = getpass.getpass('Crea una contraseña del panel (mínimo 16 caracteres): ')
        confirmation = getpass.getpass('Repite la contraseña: ')
        if len(password) < 16 or len(password) > 200 or password != confirmation:
            raise SystemExit('Las contraseñas no coinciden o no tienen entre 16 y 200 caracteres. No se ha instalado.')
        username = input('Tu usuario IPTV para autorizarte primero: ').strip()
        if not username or len(username)>200 or any(ord(x)<32 for x in username):
            raise SystemExit('Usuario no válido. No se ha instalado.')
    backup = target/('backup-panel-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
    backup.mkdir()
    shutil.copy2(docker, backup/'Dockerfile')
    if override.exists():
        shutil.copy2(override, backup/'compose.override.yaml')
    if dbfile.exists():
        with sqlite3.connect(dbfile) as original, sqlite3.connect(backup/'access.sqlite3') as copied:
            original.backup(copied)
    state.mkdir(mode=0o700, exist_ok=True)
    if fresh:
        salt = secrets.token_bytes(32)
        digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600000).hex()
        with sqlite3.connect(dbfile) as db:
            db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
            db.execute('CREATE TABLE clients(username TEXT PRIMARY KEY,name TEXT NOT NULL,enabled INTEGER NOT NULL,created REAL NOT NULL,last_seen REAL NOT NULL)')
            db.executemany('INSERT INTO settings VALUES(?,?)', [('salt',salt.hex()),('password_hash',digest)])
            import time
            db.execute('INSERT INTO clients VALUES(?,?,1,?,0)', (username,'Administrador',time.time()))
        del password, confirmation
    os.chmod(state,0o700)
    os.chown(state,10001,10001)
    os.chmod(dbfile,0o600)
    os.chown(dbfile,10001,10001)
    shutil.copy2(source/'admin_gate.py',target/'admin_gate.py')
    shutil.copytree(source/'admin_assets',target/'admin_assets',dirs_exist_ok=True)
    if 'COPY admin_gate.py' not in text:
        text = text.replace('COPY server.py .','COPY server.py .\nCOPY admin_gate.py .\nCOPY admin_assets ./admin_assets')
        if 'COPY admin_gate.py' not in text:
            raise SystemExit('No se encontró la instrucción COPY. Restaurar desde '+str(backup))
    docker.write_text(text.replace('server:application','admin_gate:application'))
    override.write_text(expected)
    subprocess.run(['docker','compose','config','--quiet'],cwd=target,check=True)
    subprocess.run(['docker','compose','up','-d','--build'],cwd=target,check=True)
    print('\nPanel instalado: https://web.promatrix.es/admin')
    print('Tu usuario IPTV está autorizado. El resto necesita que lo añadas en el panel.')
    print('Lista de clientes persistente: se conserva al reconstruir o reiniciar la web.')
    print('Copia de configuración anterior: '+str(backup))

if __name__ == '__main__':
    main()
