'use strict';
setInterval(async()=>{
 const app=document.getElementById('app');
 if(document.hidden||!app||app.hidden)return;
 try{
  const response=await fetch('/api/access-status',{credentials:'same-origin',cache:'no-store'});
  if(response.status===401||response.status===403){
   if(typeof showLogin==='function')showLogin();
   if(typeof toast==='function')toast('Tu sesión se ha cerrado o tu acceso ya no está autorizado.');
  }
 }catch{}
},30000);
