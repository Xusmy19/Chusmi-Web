# Chusmi Pro Matrix · Web independiente

Proyecto separado para tu dominio y VPS. No modifica ningún archivo Android,
no registra dispositivos en Render y no llama al panel de activación de la APK.
Los usuarios entran con su usuario y contraseña IPTV. El administrador configura
una sola dirección de proveedor en el servidor.

## Qué incluye

- Diseño Matrix con el logo y fondo de la app, adaptable a ordenador y móvil.
- TV en directo HLS, categorías, búsqueda, actualización y cambio de canal.
- Películas, fichas y reproducción; series con temporadas y episodios.
- Descargas de películas y episodios a través del gestor del navegador.
- Favoritos por usuario en este navegador.
- Credenciales en memoria del servidor; cookie de sesión opaca HttpOnly.
- Catálogo con caché de 5 minutos y renovación manual.
- Vídeo a través del VPS para evitar CORS y contenido mixto HTTP/HTTPS.
- Al cerrar el reproductor se destruye HLS y se desconecta el vídeo.
  Al cancelar una descarga, el generador cierra la conexión al proveedor
  cuando el servidor detecta el cierre del cliente. El panel del proveedor
  puede tardar en actualizar su estado; no se fuerza cambiando a otro canal.

## Instalación en tu VPS

Necesitas Docker con Compose y un proxy Nginx con HTTPS. No ejecutes estas
instrucciones sobre el proyecto Android ni sobre la carpeta del panel Render.

1. Descomprime este ZIP en una carpeta nueva, por ejemplo `/opt/chusmi-web`.
2. Copia `.env.example` como `.env`.
3. En `.env`, cambia `IPTV_SERVER` por el origen real de tu proveedor,
   por ejemplo `http://servidor-del-proveedor:8080`, sin barra final ni ruta.
   No es `https://chusmi-pro-panel.onrender.com` ni la página del webplayer.
   No pegues cuentas de usuarios en ese archivo.
4. Si el proveedor redirige los vídeos a otros servidores, añade sus orígenes
   exactos separados por comas en `MEDIA_ORIGINS`. Solo se permiten destinos
   públicos. No uses comodines ni añadas direcciones que no conozcas.
5. En esa carpeta ejecuta `docker compose up -d --build`.
6. Crea un subdominio nuevo, como `web.tudominio.es`, apuntando al VPS.
7. Usa `nginx.conf.example` como bloque nuevo y sustituye el dominio.
   Conserva la configuración de cualquier otro servicio del VPS.
   Si el puerto local 8080 está ocupado, cambia el primer 8080 de Compose
   y el destino `proxy_pass` por otro puerto libre.
8. Configura HTTPS con tu gestor de certificados. La cookie segura requiere
   HTTPS: el acceso final debe ser `https://web.tudominio.es`.
9. Entra con una cuenta IPTV y prueba un canal, una película, un episodio,
   una descarga y su cancelación antes de compartir la dirección.

## Prueba local

Python 3.10 o posterior, sin dependencias para el servidor de prueba:

    COOKIE_SECURE=0 IPTV_SERVER=https://TU-PROVEEDOR python3 server.py

Abre `http://127.0.0.1:8080`. El servidor de prueba es solo para desarrollo;
la instalación de producción usa Gunicorn. Usa un único worker, porque las
sesiones viven en memoria. Un reinicio obliga a los usuarios a iniciar sesión
otra vez. El contenedor utiliza 64 hilos: dimensiona el VPS antes de atender
muchos usuarios o descargas simultáneas.

## Límites y comprobaciones pendientes

Esta es la primera versión funcional para instalar y probar. No se ha probado
contra tu proveedor real porque su dirección y una cuenta de prueba no están
incluidas en el ZIP Android. La app recibe esos datos desde el panel de
activación y no se ha consultado ese panel.

La TV requiere que el proveedor ofrezca `/live/usuario/contraseña/ID.m3u8`.
Un navegador no reproduce todos los formatos que sí puede reproducir VLC en
Android; MKV, ciertos códecs de audio/vídeo y streams TS sin HLS pueden fallar.
Esta versión no convierte ni transcodifica vídeo. Puedes descargar los
archivos de películas y episodios para reproducirlos con VLC.

La librería HLS.js 1.5.18 se carga desde jsDelivr. Si ese CDN no está disponible,
Safari puede usar HLS nativo; otros navegadores mostrarán un mensaje. Para
alojar esa dependencia también en el VPS, guarda `hls.min.js` en `static/`
y cambia la dirección del script en `templates/index.html` a
`/static/hls.min.js`.

Los favoritos web son independientes. No se ha integrado el control parental
remoto ni la activación por dispositivo de la app. Esta web no hereda esos
bloqueos; no compartas una cuenta que tenga categorías que deban estar
restringidas sin añadir primero un control de acceso equivalente.

El uso web comparte los límites de conexión de la cuenta IPTV con la APK.
Una descarga o reproducción consume una conexión del proveedor, aunque no se
modifique la aplicación. No se pueden garantizar reproducciones simultáneas
si la cuenta solo permite una. Evita descargar y ver otro contenido a la vez.

Los vídeos y descargas pasan por el VPS: consumen su ancho de banda de entrada
y salida. Usa un subdominio separado y revisa la capacidad del servidor. No se
almacenan vídeos completos ni se escriben contraseñas en los logs de acceso.
Las sesiones caducan a las 12 horas y se limitan a 1000 sesiones por proceso.
La descarga usa el gestor del navegador: no hay biblioteca offline dentro de
la web. Los archivos descargados se guardan en el dispositivo.

No incluye cambios ni despliegues en la APK, en GitHub o en tu panel existente.
