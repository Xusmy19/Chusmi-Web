"""Offline functional checks with a simulated provider. No real credentials."""
import io, json, unittest
from unittest.mock import patch
import server

class FakeResponse(io.BytesIO):
    def __init__(self, payload, headers=None, status=200):
        super().__init__(payload); self.headers=headers or {}; self.status=status
    def __enter__(self): return self
    def __exit__(self,*args): self.close()

class AppTests(unittest.TestCase):
    def setUp(self):
        server.SESSIONS.clear();server.ATTEMPTS.clear()
        self.config=patch.multiple(server,SERVER='https://provider.example',ORIGINS={'https://provider.example'},SECURE=False)
        self.config.start();self.addCleanup(self.config.stop)
        self.validation=patch.object(server.socket,'getaddrinfo',return_value=[(None,None,None,None,('8.8.8.8',443))])
        self.validation.start();self.addCleanup(self.validation.stop)
        self.cookie=''
    def request(self,path,method='GET',data=None,extra=None,consume=True):
        path,_,query=path.partition('?'); raw=json.dumps(data or {}).encode()
        env={'PATH_INFO':path,'QUERY_STRING':query,'REQUEST_METHOD':method,'CONTENT_TYPE':'application/json','CONTENT_LENGTH':str(len(raw)), 'wsgi.input':io.BytesIO(raw),'wsgi.url_scheme':'https','HTTP_HOST':'web.example','REMOTE_ADDR':'1.2.3.4','HTTP_COOKIE':self.cookie}
        env.update(extra or {}); status={}
        def start(s,h):status.update(status=int(s[:3]),headers=dict(h))
        response=server.application(env,start)
        if consume: status['body']=b''.join(response)
        else: status['iterator']=response
        if status['headers'].get('Set-Cookie'):self.cookie=status['headers']['Set-Cookie'].split(';')[0]
        return status
    def login(self):
        with patch.object(server,'provider',return_value={'user_info':{'auth':1,'status':'Active','exp_date':'1900000000'}}):
            response=self.request('/api/login','POST',{'username':'demo','password':'test'})
        self.assertEqual(response['status'],200);self.assertNotIn(b'test',response['body'])
    def test_static_and_login_lifecycle(self):
        self.assertEqual(self.request('/')['status'],200)
        self.assertEqual(self.request('/static/app.js')['status'],200)
        self.assertEqual(self.request('/static/../../server.py')['status'],404)
        self.assertEqual(self.request('/api/me')['status'],401)
        self.login();self.assertEqual(self.request('/api/me')['status'],200)
        self.assertEqual(self.request('/api/logout','POST')['status'],200)
        self.assertEqual(self.request('/api/me')['status'],401)
    def test_csrf_invalid_account_and_limits(self):
        self.assertEqual(self.request('/api/login','POST',{'username':'x','password':'y'},{'HTTP_ORIGIN':'https://evil.example'})['status'],403)
        with patch.object(server,'provider',return_value={'user_info':{'auth':0}}):
            for _ in range(15): self.assertEqual(self.request('/api/login','POST',{'username':'x','password':'y'})['status'],401)
            self.assertEqual(self.request('/api/login','POST',{'username':'x','password':'y'})['status'],429)
    def test_catalog_refresh_and_action_validation(self):
        self.login()
        with patch.object(server,'provider',side_effect=[[{'name':'First'}],[{'name':'Updated'}]]) as mock:
            a=self.request('/api/catalog?action=get_live_streams')
            b=self.request('/api/catalog?action=get_live_streams')
            c=self.request('/api/catalog?action=get_live_streams&refresh=1')
            self.assertEqual(a['body'],b['body']);self.assertIn(b'Updated',c['body']);self.assertEqual(mock.call_count,2)
        self.assertEqual(self.request('/api/catalog?action=delete_user')['status'],400)
    def test_movie_download_range_and_close(self):
        self.login()
        response=self.request('/api/play','POST',{'kind':'movie','id':'42','extension':'mp4','download':True,'name':'Película'})
        media=json.loads(response['body'])['url'];self.assertNotIn('test',media)
        upstream=FakeResponse(b'x'*90000,{'Content-Type':'video/mp4','Content-Length':'90000','Content-Range':'bytes 0-89999/90000'},206)
        with patch.object(server,'upstream',return_value=(upstream,'https://provider.example/movie/demo/test/42.mp4')):
            output=self.request(media,extra={'HTTP_RANGE':'bytes=0-'},consume=False)
            self.assertEqual(output['status'],206);self.assertIn('attachment',output['headers']['Content-Disposition'])
            self.assertEqual(len(next(output['iterator'])),32768)
            output['iterator'].close();self.assertTrue(upstream.closed)
    def test_hls_nested_resources_rewritten(self):
        self.login();response=self.request('/api/play','POST',{'kind':'live','id':'5'})
        media=json.loads(response['body'])['url']
        manifest=b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key.bin"\n#EXTINF:5,\nsegment.ts\n'
        with patch.object(server,'upstream',return_value=(FakeResponse(manifest,{'Content-Type':'application/vnd.apple.mpegurl'}),'https://provider.example/live/demo/test/5.m3u8')):
            output=self.request(media)
        self.assertEqual(output['status'],200);self.assertNotIn(b'provider.example',output['body']);self.assertEqual(output['body'].count(b'/media/'),2)
        self.assertEqual(self.request('/api/play','POST',{'kind':'live','id':'5','download':True})['status'],400)
    def test_block_unknown_and_private_destinations(self):
        with self.assertRaises(server.Failure):server.safe_url('https://other.example/video')
        with self.assertRaises(server.Failure):server.safe_url('file:///etc/passwd')
        with patch.object(server.socket,'getaddrinfo',return_value=[(None,None,None,None,('127.0.0.1',443))]):
            with self.assertRaises(server.Failure):server.safe_url('https://provider.example/video')

if __name__=='__main__':unittest.main()
