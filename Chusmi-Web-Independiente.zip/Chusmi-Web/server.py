"""Chusmi Web: WSGI application, isolated from the Android activation panel."""
import os, json, secrets, time, threading, re, socket, ipaddress, mimetypes
from pathlib import Path
from urllib.parse import urlsplit, urljoin, urlencode, quote, parse_qs
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from http.cookies import SimpleCookie

ROOT = Path(__file__).resolve().parent
SERVER = os.environ.get('IPTV_SERVER', '').rstrip('/')
ORIGINS = {x.strip().rstrip('/') for x in os.environ.get('MEDIA_ORIGINS', '').split(',') if x.strip()}
if SERVER: ORIGINS.add(SERVER)
SECURE = os.environ.get('COOKIE_SECURE', '1') != '0'
SESSIONS, ATTEMPTS = {}, {}
LOCK = threading.RLock()
TTL = 12 * 3600
ACTIONS = {'get_live_categories','get_live_streams','get_vod_categories','get_vod_streams','get_series_categories','get_series','get_series_info','get_vod_info','get_short_epg'}
class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args): return None
OPENER = build_opener(NoRedirect())
class Failure(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

def origin(url):
    p = urlsplit(url)
    return p.scheme + '://' + p.netloc

def safe_url(url):
    p = urlsplit(url)
    if p.scheme not in ('http','https') or not p.hostname or p.username or p.password or origin(url) not in ORIGINS:
        raise Failure(502, 'El proveedor utiliza otro servidor de vídeo. Añade su origen a MEDIA_ORIGINS en el VPS.')
    # Never let a provider redirect turn the VPS into a private-network proxy.
    try:
        addresses = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == 'https' else 80), type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
            raise Failure(502, 'Dirección del proveedor no permitida.')
    except socket.gaierror:
        raise Failure(502, 'No se pudo resolver el servidor del proveedor.')
    return url

def upstream(url, headers=None):
    for _ in range(6):
        safe_url(url)
        try:
            response = OPENER.open(Request(url, headers={'User-Agent':'Chusmi-Web/1.0', **(headers or {})}), timeout=25)
            return response, url
        except HTTPError as e:
            if e.code in (301,302,303,307,308) and e.headers.get('Location'):
                url = urljoin(url, e.headers['Location']); e.close(); continue
            e.close(); raise Failure(502, 'El proveedor no ha entregado el contenido solicitado.')
        except (URLError, TimeoutError, OSError):
            raise Failure(502, 'No se pudo conectar con el proveedor. Vuelve a intentarlo.')
    raise Failure(502, 'Demasiadas redirecciones del proveedor.')

def provider(account, action='', extra=None):
    q = {'username':account['username'], 'password':account['password']}
    if action: q['action'] = action
    q.update(extra or {})
    response, _ = upstream(SERVER + '/player_api.php?' + urlencode(q))
    with response:
        data = response.read(32 * 1024 * 1024 + 1)
    if len(data) > 32 * 1024 * 1024: raise Failure(502, 'Catálogo demasiado grande.')
    try: return json.loads(data)
    except (ValueError, UnicodeError): raise Failure(502, 'Respuesta del proveedor no válida.')

def cleanup():
    now = time.time()
    with LOCK:
        for k in list(SESSIONS):
            if SESSIONS[k]['expires'] < now: del SESSIONS[k]
        for k in list(ATTEMPTS):
            if ATTEMPTS[k][0] < now - 600: del ATTEMPTS[k]

def account_for(env):
    jar = SimpleCookie()
    try: jar.load(env.get('HTTP_COOKIE',''))
    except Exception: pass
    sid = jar.get('chusmi_session')
    with LOCK: account = SESSIONS.get(sid.value) if sid else None
    if not account or account['expires'] < time.time(): raise Failure(401, 'Inicia sesión para continuar.')
    return account

def body(env):
    try:
        length = int(env.get('CONTENT_LENGTH') or 0)
        if length < 0 or length > 4096: raise ValueError()
        data = json.loads(env['wsgi.input'].read(length))
        if not isinstance(data, dict): raise ValueError()
        return data
    except (ValueError, UnicodeError): raise Failure(400, 'Solicitud no válida.')

def token_for(account, url):
    safe_url(url)
    with LOCK:
        old = account['reverse'].get(url)
        if old: return old
        if len(account['media']) > 20000: raise Failure(429, 'Cierra sesión y vuelve a entrar para renovar la sesión.')
        token = secrets.token_urlsafe(24)
        account['media'][token] = url; account['reverse'][url] = token
    return token

def media_path(account, url): return '/media/' + token_for(account, url)

def rewrite_playlist(account, text, base):
    def attribute(m): return 'URI="' + media_path(account, urljoin(base,m.group(1))) + '"'
    lines = []
    for line in text.splitlines():
        if line.startswith('#'): line = re.sub(r'URI="([^"]+)"', attribute, line)
        elif line.strip(): line = media_path(account,urljoin(base,line.strip()))
        lines.append(line)
    return '\n'.join(lines) + '\n'

def application(env, start_response):
    cleanup()
    path, method = env.get('PATH_INFO','/'), env['REQUEST_METHOD']
    headers = [('Cache-Control','no-store'), ('X-Content-Type-Options','nosniff'), ('Referrer-Policy','no-referrer'), ('X-Frame-Options','DENY')]
    def send(status, payload, ctype='application/json; charset=utf-8', extra=()):
        if ctype.startswith('application/json'): payload = json.dumps(payload, ensure_ascii=False).encode()
        elif isinstance(payload,str): payload = payload.encode()
        start_response(f'{status} ' + {200:'OK',204:'No Content',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',429:'Too Many Requests',502:'Bad Gateway',503:'Service Unavailable'}.get(status,'Error'), headers + [('Content-Type',ctype),('Content-Length',str(len(payload)))] + list(extra))
        return [payload]
    try:
        if method == 'POST':
            if env.get('HTTP_SEC_FETCH_SITE') == 'cross-site': raise Failure(403,'Solicitud de otro sitio bloqueada.')
            supplied_origin = env.get('HTTP_ORIGIN')
            if supplied_origin and supplied_origin != env.get('wsgi.url_scheme','http') + '://' + env.get('HTTP_HOST',''):
                raise Failure(403,'Origen no permitido.')
            if not env.get('CONTENT_TYPE','').startswith('application/json'): raise Failure(400,'Usa una solicitud JSON.')
        if path == '/api/login' and method == 'POST':
            if not SERVER: raise Failure(503,'Falta configurar IPTV_SERVER en el VPS.')
            key = env.get('HTTP_X_REAL_IP', env.get('REMOTE_ADDR','unknown')) if os.environ.get('TRUST_PROXY') == '1' else env.get('REMOTE_ADDR','unknown')
            with LOCK:
                first, count = ATTEMPTS.get(key,(time.time(),0))
                if count >= 15: raise Failure(429,'Demasiados intentos. Espera diez minutos.')
                ATTEMPTS[key] = (first,count+1)
            data = body(env)
            username, password = str(data.get('username','')).strip(), str(data.get('password',''))
            if not username or not password or len(username)>200 or len(password)>200: raise Failure(400,'Introduce usuario y contraseña.')
            data = {'username':username, 'password':password}
            info = provider(data).get('user_info',{})
            if str(info.get('auth')) != '1' or str(info.get('status','')).lower() != 'active': raise Failure(401,'Cuenta incorrecta, caducada o inactiva.')
            sid = secrets.token_urlsafe(32)
            data.update(expires=time.time()+TTL,media={},reverse={},cache={},user=info)
            with LOCK:
                if len(SESSIONS)>=1000: raise Failure(503,'La web está ocupada. Inténtalo más tarde.')
                # Rotate an existing session instead of leaving its credentials alive.
                jar = SimpleCookie(); jar.load(env.get('HTTP_COOKIE',''))
                if jar.get('chusmi_session'): SESSIONS.pop(jar['chusmi_session'].value,None)
                SESSIONS[sid] = data
            cookie = f'chusmi_session={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age={TTL}' + ('; Secure' if SECURE else '')
            return send(200, {'username':username,'expires':info.get('exp_date'),'max_connections':info.get('max_connections')},extra=[('Set-Cookie',cookie)])
        if path == '/api/logout' and method == 'POST':
            jar=SimpleCookie(); jar.load(env.get('HTTP_COOKIE',''))
            with LOCK:
                if jar.get('chusmi_session'): SESSIONS.pop(jar['chusmi_session'].value,None)
            return send(200, {'ok':True},extra=[('Set-Cookie','chusmi_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0' + ('; Secure' if SECURE else ''))])
        if path.startswith('/api/') or path.startswith('/media/'):
            account = account_for(env)
            if path == '/api/me' and method == 'GET':
                return send(200,{'username':account['username'],'expires':account['user'].get('exp_date'),'max_connections':account['user'].get('max_connections')})
            if path == '/api/catalog' and method == 'GET':
                args=parse_qs(env.get('QUERY_STRING','')); action=args.get('action',[''])[0]
                if action not in ACTIONS: raise Failure(400,'Acción no válida.')
                extra={k:args[k][0] for k in ('series_id','vod_id','stream_id','limit') if k in args and re.fullmatch(r'\d{1,12}',args[k][0])}
                cachekey=action+urlencode(extra)
                with LOCK: cached=account['cache'].get(cachekey)
                if cached and cached[0] > time.time() and args.get('refresh') != ['1']: return send(200,cached[1])
                result=provider(account,action,extra)
                if action not in ('get_series_info','get_vod_info','get_short_epg'):
                    with LOCK: account['cache'][cachekey]=(time.time()+300,result)
                return send(200,result)
            if path == '/api/play' and method == 'POST':
                data=body(env); kind=data.get('kind'); ident=str(data.get('id','')); ext=str(data.get('extension','mp4'))
                if kind not in ('live','movie','series') or not re.fullmatch(r'\d{1,12}',ident) or not re.fullmatch(r'[a-zA-Z0-9]{1,8}',ext): raise Failure(400,'Contenido no válido.')
                if kind=='live': ext='m3u8'
                url=SERVER + '/' + kind + '/' + quote(account['username'],safe='') + '/' + quote(account['password'],safe='') + '/' + ident + '.' + ext
                download=bool(data.get('download'))
                if download and kind=='live': raise Failure(400,'Solo se pueden descargar películas y episodios.')
                name=re.sub(r'[^\w .-]','',str(data.get('name','video')))[:100] or 'video'
                return send(200,{'url':media_path(account,url)+ ('?download='+quote(name+'.'+ext) if download else '')})
            if path.startswith('/media/') and method == 'GET':
                with LOCK: url=account['media'].get(path[len('/media/'):])
                if not url: raise Failure(404,'Enlace caducado. Vuelve a abrir el contenido.')
                range_header=env.get('HTTP_RANGE','')
                if range_header and not re.fullmatch(r'bytes=\d*-\d*',range_header): raise Failure(400,'Rango no válido.')
                response, final_url=upstream(url,{'Range':range_header} if range_header else {})
                ctype=response.headers.get('Content-Type','application/octet-stream')
                if '.m3u8' in urlsplit(final_url).path.lower() or 'mpegurl' in ctype.lower():
                    with response: data=response.read(2*1024*1024+1)
                    if len(data)>2*1024*1024: raise Failure(502,'Lista de reproducción demasiado grande.')
                    return send(200,rewrite_playlist(account,data.decode('utf-8-sig'),final_url),'application/vnd.apple.mpegurl')
                passthrough=[(k,response.headers[k]) for k in ('Content-Length','Content-Range','Accept-Ranges') if response.headers.get(k)]
                download=parse_qs(env.get('QUERY_STRING','')).get('download',[''])[0]
                if download: passthrough.append(('Content-Disposition',"attachment; filename*=UTF-8''"+quote(download)))
                start_response(str(response.status)+' '+('Partial Content' if response.status==206 else 'OK'),headers+[('Content-Type',ctype)]+passthrough)
                def chunks():
                    try:
                        while account['expires']>time.time():
                            with LOCK:
                                if not any(value is account for value in SESSIONS.values()): break
                            chunk=response.read(32768)
                            if not chunk: break
                            yield chunk
                    finally: response.close()
                return chunks()
            raise Failure(404,'Ruta no encontrada.')
        if method != 'GET': raise Failure(405,'Método no permitido.')
        file = ROOT / ('templates/index.html' if path=='/' else path.lstrip('/'))
        if path!='/' and not path.startswith('/static/'): raise Failure(404,'Página no encontrada.')
        if not file.resolve().is_relative_to(ROOT) or not file.is_file(): raise Failure(404,'Archivo no encontrado.')
        ctype=mimetypes.guess_type(file)[0] or 'application/octet-stream'
        if path=='/':
            headers.append(('Content-Security-Policy',"default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self'; img-src 'self' https: data:; media-src 'self' blob:; connect-src 'self'; worker-src blob:; frame-ancestors 'none'; base-uri 'self'"))
        return send(200,file.read_bytes(),ctype)
    except Failure as e: return send(e.status,{'error':e.message})
    except Exception: return send(502,{'error':'No se pudo completar la solicitud. Vuelve a intentarlo.'})

if __name__=='__main__':
    from wsgiref.simple_server import make_server, WSGIServer, WSGIRequestHandler
    from socketserver import ThreadingMixIn
    class ThreadServer(ThreadingMixIn,WSGIServer): daemon_threads=True
    class QuietHandler(WSGIRequestHandler):
        def log_message(self, *args): pass
    print('Prueba local: http://127.0.0.1:8080 (producción: Gunicorn y Nginx)')
    make_server('127.0.0.1',8080,application,ThreadServer,QuietHandler).serve_forever()
